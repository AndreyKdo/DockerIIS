// =================================================================
// DockerWebinar - lógica de front-end
// Cada API se llama por separado y sus errores se manejan por
// separado: si api-pagos cae, api-consultas sigue funcionando y
// viceversa. Esto es justo lo que queremos evidenciar en el webinar.
// =================================================================

const money = (n) =>
  new Intl.NumberFormat("es-CR", { style: "currency", currency: "CRC" }).format(n || 0);

function setEstadoBadge(elId, online) {
  const el = document.getElementById(elId);
  el.classList.remove("status-checking", "status-online", "status-offline");
  if (online) {
    el.classList.add("status-online");
    el.innerHTML = '<span class="dot"></span>en línea';
  } else {
    el.classList.add("status-offline");
    el.innerHTML = '<span class="dot"></span>caído';
  }
}

function mostrarAlerta(slotId, tipo, mensaje) {
  const slot = document.getElementById(slotId);
  const icono = tipo === "success" ? "fa-circle-check" : "fa-triangle-exclamation";
  slot.innerHTML = `
    <div class="alert alert-${tipo} d-flex align-items-start gap-2 mb-0" role="alert">
      <i class="fa-solid ${icono} mt-1"></i>
      <div>${mensaje}</div>
    </div>`;
}

function limpiarAlerta(slotId) {
  document.getElementById(slotId).innerHTML = "";
}

// -----------------------------------------------------------------
// Extrae el detalle real del error devuelto por la API (Results.Problem
// manda { title, detail, status }). Antes solo mostrábamos el código
// HTTP y se perdía el mensaje real de SqlException (timeout, login
// failed, host no alcanzable, etc.). Ahora lo leemos del body.
// -----------------------------------------------------------------
async function extraerDetalle(resp) {
  try {
    const body = await resp.json();
    return body.detail || body.title || `estado HTTP ${resp.status}`;
  } catch {
    return `estado HTTP ${resp.status}`;
  }
}

// -----------------------------------------------------------------
// Health checks independientes por microservicio
// -----------------------------------------------------------------
async function chequearServicio(url, badgeId) {
  try {
    const resp = await fetch(`${url}/health`, { signal: AbortSignal.timeout(4000) });
    setEstadoBadge(badgeId, resp.ok);
  } catch {
    setEstadoBadge(badgeId, false);
  }
}

function chequearTodos() {
  chequearServicio(CONFIG.API_PAGOS_URL, "badge-pagos");
  chequearServicio(CONFIG.API_CONSULTAS_URL, "badge-consultas");
}

// -----------------------------------------------------------------
// Registrar cliente -> api-pagos
// -----------------------------------------------------------------
document.getElementById("form-cliente").addEventListener("submit", async (e) => {
  e.preventDefault();
  limpiarAlerta("alert-cliente");

  const payload = {
    cedula: document.getElementById("cliente-cedula").value.trim(),
    nombre: document.getElementById("cliente-nombre").value.trim(),
    saldo: parseFloat(document.getElementById("cliente-saldo").value) || 0
  };

  try {
    const resp = await fetch(`${CONFIG.API_PAGOS_URL}/api/clientes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(6000)
    });

    if (!resp.ok) throw new Error(await extraerDetalle(resp));

    const data = await resp.json();
    mostrarAlerta("alert-cliente", "success", `Cliente #${data.clienteId} guardado correctamente.`);
    e.target.reset();
    setEstadoBadge("badge-pagos", true);
  } catch (err) {
    mostrarAlerta(
      "alert-cliente",
      "danger",
      `<strong>No se pudo registrar el cliente.</strong> El contenedor <span class="mono">api-pagos</span> respondió, pero falló al escribir en SQL Server.<br><span class="mono small">${err.message}</span>`
    );
    setEstadoBadge("badge-pagos", false);
  }
});

// -----------------------------------------------------------------
// Registrar pago -> api-pagos
// -----------------------------------------------------------------
document.getElementById("form-pago").addEventListener("submit", async (e) => {
  e.preventDefault();
  limpiarAlerta("alert-pago");

  const payload = {
    clienteId: parseInt(document.getElementById("pago-clienteid").value, 10),
    monto: parseFloat(document.getElementById("pago-monto").value) || 0,
    referencia: document.getElementById("pago-referencia").value.trim(),
    estado: document.getElementById("pago-estado").value
  };

  try {
    const resp = await fetch(`${CONFIG.API_PAGOS_URL}/api/pagos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(6000)
    });

    if (!resp.ok) throw new Error(await extraerDetalle(resp));

    const data = await resp.json();
    mostrarAlerta("alert-pago", "success", `Pago #${data.pagoId} guardado correctamente.`);
    e.target.reset();
    setEstadoBadge("badge-pagos", true);
  } catch (err) {
    mostrarAlerta(
      "alert-pago",
      "danger",
      `<strong>No se pudo registrar el pago.</strong> El contenedor <span class="mono">api-pagos</span> respondió, pero falló al escribir en SQL Server.<br><span class="mono small">${err.message}</span>`
    );
    setEstadoBadge("badge-pagos", false);
  }
});

// -----------------------------------------------------------------
// Consultar clientes -> api-consultas
// -----------------------------------------------------------------
async function cargarClientes() {
  limpiarAlerta("alert-clientes");
  const tbody = document.getElementById("tabla-clientes");

  try {
    const resp = await fetch(`${CONFIG.API_CONSULTAS_URL}/api/clientes`, {
      signal: AbortSignal.timeout(6000)
    });
    if (!resp.ok) throw new Error(await extraerDetalle(resp));

    const clientes = await resp.json();
    setEstadoBadge("badge-consultas", true);

    if (!clientes.length) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-secondary text-center py-4">No hay clientes registrados aún</td></tr>`;
      return;
    }

    tbody.innerHTML = clientes.map(c => `
      <tr>
        <td class="mono">${c.clienteId}</td>
        <td>${c.cedula ?? ""}</td>
        <td>${c.nombre ?? ""}</td>
        <td class="text-end">${money(c.saldo)}</td>
      </tr>`).join("");
  } catch (err) {
    setEstadoBadge("badge-consultas", false);
    tbody.innerHTML = `<tr><td colspan="4" class="text-secondary text-center py-4">No se pudieron cargar los datos</td></tr>`;
    mostrarAlerta(
      "alert-clientes",
      "danger",
      `<strong>No se pudieron cargar los clientes.</strong> El contenedor <span class="mono">api-consultas</span> respondió, pero falló al leer de SQL Server.<br><span class="mono small">${err.message}</span>`
    );
  }
}

// -----------------------------------------------------------------
// Consultar pagos -> api-consultas
// -----------------------------------------------------------------
async function cargarPagos() {
  limpiarAlerta("alert-pagos");
  const tbody = document.getElementById("tabla-pagos");

  try {
    const resp = await fetch(`${CONFIG.API_CONSULTAS_URL}/api/pagos`, {
      signal: AbortSignal.timeout(6000)
    });
    if (!resp.ok) throw new Error(await extraerDetalle(resp));

    const pagos = await resp.json();
    setEstadoBadge("badge-consultas", true);

    if (!pagos.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="text-secondary text-center py-4">No hay pagos registrados aún</td></tr>`;
      return;
    }

    tbody.innerHTML = pagos.map(p => `
      <tr>
        <td class="mono">${p.pagoId}</td>
        <td>${p.clienteNombre ?? ""}</td>
        <td class="text-end">${money(p.monto)}</td>
        <td class="mono small">${p.fecha ? new Date(p.fecha).toLocaleString("es-CR") : ""}</td>
        <td><span class="badge bg-secondary">${p.estado ?? ""}</span></td>
      </tr>`).join("");
  } catch (err) {
    setEstadoBadge("badge-consultas", false);
    tbody.innerHTML = `<tr><td colspan="5" class="text-secondary text-center py-4">No se pudieron cargar los datos</td></tr>`;
    mostrarAlerta(
      "alert-pagos",
      "danger",
      `<strong>No se pudieron cargar los pagos.</strong> El contenedor <span class="mono">api-consultas</span> respondió, pero falló al leer de SQL Server.<br><span class="mono small">${err.message}</span>`
    );
  }
}

document.getElementById("btn-cargar-clientes").addEventListener("click", cargarClientes);
document.getElementById("btn-cargar-pagos").addEventListener("click", cargarPagos);
document.getElementById("btn-refresh").addEventListener("click", () => {
  chequearTodos();
  cargarClientes();
  cargarPagos();
});

// Carga inicial
chequearTodos();
cargarClientes();
cargarPagos();

// Re-chequeo periódico del estado de los servicios
setInterval(chequearTodos, 15000);
