// ---------------------------------------------------------------
// Configuracion central de endpoints.
// Si cambias los puertos publicados en docker-compose, solo hay
// que tocar este archivo (no hace falta reconstruir la imagen,
// basta con editar el volumen montado ./web/wwwroot).
// ---------------------------------------------------------------
const CONFIG = {
  API_PAGOS_URL: "http://localhost:5001",
  API_CONSULTAS_URL: "http://localhost:5002"
};
