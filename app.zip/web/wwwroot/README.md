# DockerWebinar — Laboratorio híbrido Windows + Linux Containers

## Estructura del proyecto

```
dockerwebinar/
├── docker-compose.yml        <- Motor Windows: web + api-pagos + api-consultas
├── web/
│   ├── Dockerfile             <- Imagen IIS (Windows)
│   └── wwwroot/
│       ├── index.html
│       ├── css/style.css
│       └── js/{config.js, app.js}
├── api-pagos/                 <- Microservicio de INSERCIÓN (.NET 8, Windows container)
│   ├── Dockerfile
│   ├── ApiPagos.csproj
│   └── Program.cs
├── api-consultas/              <- Microservicio de CONSULTA (.NET 8, Windows container)
│   ├── Dockerfile
│   ├── ApiConsultas.csproj
│   └── Program.cs
└── sql/
    └── init-dockerwebinar.sql <- Crea la base DockerWebinar y las tablas Clientes/Pagos
```

El SQL Server (Linux container en WSL2) se queda exactamente como ya lo tenías corriendo;
no se toca ese `docker-compose` porque los dos motores son independientes.

## Pasos para levantar el laboratorio

1. **Prepara la base de datos** (una sola vez). Desde SSMS, conectado a `192.168.92.148,1433`
   con el usuario `sa`, ejecuta el script `sql/init-dockerwebinar.sql`. Esto crea la base
   `DockerWebinar`, las tablas `Clientes` y `Pagos`, y algunos clientes de ejemplo.

2. **Confirma la IP actual del contenedor Linux** (puede cambiar al reiniciar WSL2/Docker):

   ```powershell
   wsl docker inspect -f "{{.NetworkSettings.Networks.bridge.IPAddress}}" sqlserver
   ```

   Si cambió, actualiza el valor de `SQL_SERVER` en `docker-compose.yml` (está repetido en
   `api-pagos` y `api-consultas`) y en `web/wwwroot/js/config.js` si moviste los puertos.

3. **Verifica que Docker Desktop esté en modo "Switch to Windows containers..."** (clic derecho
   sobre el ícono de Docker Desktop en la bandeja del sistema).

4. **Levanta los tres servicios Windows**:

   ```powershell
   cd dockerwebinar
   docker compose up --build -d
   ```

5. **Abre el sitio**: [http://localhost:8000](http://localhost:8000)

## Cómo evidenciar los microservicios independientes en el webinario

Con los tres contenedores arriba, detén solo uno y muestra en vivo que el resto del sitio
sigue funcionando:

```powershell
# Apaga solo el microservicio de inserción
docker compose stop api-pagos

# En la página: los formularios "Registrar cliente" y "Registrar pago"
# muestran una alerta roja de servicio caído, mientras que las tablas
# "Clientes registrados" y "Pagos registrados" (api-consultas) siguen
# cargando datos sin problema.

docker compose start api-pagos
```

```powershell
# Ahora apaga el microservicio de consultas
docker compose stop api-consultas

# En la página: las dos tablas muestran la alerta de servicio caído,
# pero los formularios de registro (api-pagos) siguen guardando datos
# en SQL Server sin problema.

docker compose start api-consultas
```

El badge de estado de cada API en la parte superior de la página (verde/rojo) se actualiza
automáticamente cada 15 segundos, y también al presionar "Reintentar".

## Notas técnicas

- Ambos microservicios (`api-pagos`, `api-consultas`) están en imágenes **Windows**
  (`nanoserver-ltsc2022`) para vivir en el mismo `docker-compose.yml` del motor Windows,
  junto con IIS — igual que pediste, evidenciando microservicios separados dentro del
  mismo stack de contenedores Windows.
- Se habilitó CORS abierto (`AllowAnyOrigin`) en ambas APIs únicamente para fines de
  demostración del webinario; en un entorno productivo se restringiría al origen real
  del sitio.
- La cadena de conexión a SQL Server se arma con `Microsoft.Data.SqlClient` y usa
  `TrustServerCertificate=True` porque el SQL Server del contenedor Linux usa un
  certificado autofirmado.
- Si vuelves a cambiar la IP del contenedor Linux, solo necesitas actualizar las
  variables de entorno `SQL_SERVER` en `docker-compose.yml` y reiniciar los dos
  microservicios (`docker compose up -d --force-recreate api-pagos api-consultas`),
  sin tener que tocar la página web.
