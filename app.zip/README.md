# DockerWebinar — Laboratorio híbrido Windows + Linux Containers

## Estructura del proyecto

```
dockerwebinar/
├── docker-compose.yml        <- Motor Windows: web + api-pagos + api-consultas
├── web/
│   ├── Dockerfile             <- Imagen IIS (Windows)
│   └── wwwroot/
│       ├── index.html
│       ├── css/style.css
│       └── js/{config.js, app.js}
├── api-pagos/                 <- Microservicio de INSERCIÓN (.NET 8, Windows container)
│   ├── Dockerfile
│   ├── ApiPagos.csproj
│   └── Program.cs
├── api-consultas/              <- Microservicio de CONSULTA (.NET 8, Windows container)
│   ├── Dockerfile
│   ├── ApiConsultas.csproj
│   └── Program.cs
└── sql/
    └── init-dockerwebinar.sql <- Crea la base DockerWebinar y las tablas Clientes/Pagos
```

SQL Server en WSL en Docker de Linux.

Docker compose:

services:

  sqlserver:
    image: mcr.microsoft.com/mssql/server:2022-latest

    container_name: sqlserver

    environment:
      ACCEPT_EULA: "Y"
      MSSQL_PID: "Developer"
      MSSQL_SA_PASSWORD: "DockerDemo2026!"

    ports:
      - "1433:1433"

    volumes:
      - sql_data:/var/opt/mssql

volumes:
  sql_data:

## IP de la WSL:

hostname -I
192.168.92.148

Este SQL Server (Linux Ubuntu container en WSL2) se queda exactamente tal cual;
no se toca ese `docker-compose` porque los dos motores son independientes.

## Pasos para levantar el laboratorio

## Requisito de host (una sola vez): reenvío de puerto Windows → WSL2

Antes de levantar los microservicios, el host Windows necesita reenviar el puerto 1433
a **todas** las interfaces, porque WSL2 solo lo reenvía por defecto a `127.0.0.1`
(loopback) — y un contenedor Windows no puede usar el `localhost` del host. Sin este
paso, `api-pagos` y `api-consultas` fallan con
`SqlException ... The wait operation timed out.` aunque SQL Server esté corriendo bien.

En PowerShell **como administrador**, una sola vez (persiste entre reinicios del host,
incluso si cambia la IP interna de WSL2, porque ahora se usa `127.0.0.1`):

```powershell
netsh interface portproxy add v4tov4 listenaddress=0.0.0.0 listenport=1433 connectaddress=127.0.0.1 connectport=1433
```

Verificar que quedó activo:

```powershell
netsh interface portproxy show v4tov4
```

Con esto, `host.docker.internal:1433` (usado en `docker-compose.yml`) queda accesible
desde los contenedores Windows. 

Si alguna vez lo necesitas quitar:

```powershell
netsh interface portproxy delete v4tov4 listenaddress=0.0.0.0 listenport=1433
```

## Pasos para levantar el laboratorio

1. **Prepara la base de datos** (una sola vez). Desde SSMS, conectado a `192.168.92.148,1433`
   con el usuario `sa`, ejecuta el script `sql/init-dockerwebinar.sql`. Esto crea la base
   `DockerWebinar`, las tablas `Clientes` y `Pagos`, y algunos clientes de ejemplo.

2. **Verifica que Docker Desktop esté en modo "Switch to Windows containers..."** (clic derecho
   sobre el ícono de Docker Desktop en la bandeja del sistema).

3. **Levanta los tres servicios Windows**:

   ```powershell
   cd dockerwebinar
   docker compose up --build -d
   ```

4. **Abre el sitio**: [http://localhost:8000](http://localhost:8000)

## Cómo evidenciar los microservicios independientes en el webinario

Con los tres contenedores arriba, detén solo uno y muestra en vivo que el resto del sitio
sigue funcionando:

```powershell
# Apaga solo el microservicio de inserción
docker compose stop api-pagos

# En la página: los formularios "Registrar cliente" y "Registrar pago"
# muestran una alerta roja de servicio caído, mientras que las tablas
# "Clientes registrados" y "Pagos registrados" (api-consultas) siguen
# cargando datos sin problema.

docker compose start api-pagos
```

```powershell
# Ahora apaga el microservicio de consultas
docker compose stop api-consultas

# En la página: las dos tablas muestran la alerta de servicio caído,
# pero los formularios de registro (api-pagos) siguen guardando datos
# en SQL Server sin problema.

docker compose start api-consultas
```

El badge de estado de cada API en la parte superior de la página (verde/rojo) se actualiza
automáticamente cada 15 segundos, y también al presionar "Reintentar".

## Notas técnicas

- Ambos microservicios (`api-pagos`, `api-consultas`) están en imágenes **Windows**
  (`nanoserver-ltsc2022`) para vivir en el mismo `docker-compose.yml` del motor Windows,
  junto con IIS — igual que pediste, evidenciando microservicios separados dentro del
  mismo stack de contenedores Windows.
- Se habilitó CORS abierto (`AllowAnyOrigin`) en ambas APIs únicamente para fines de
  demostración del webinario; en un entorno productivo se restringiría al origen real
  del sitio.
- La cadena de conexión a SQL Server se arma con `Microsoft.Data.SqlClient` y usa
  `TrustServerCertificate=True` porque el SQL Server del contenedor Linux usa un
  certificado autofirmado.
- Si vuelves a cambiar la IP del contenedor Linux, solo necesitas actualizar las
  variables de entorno `SQL_SERVER` en `docker-compose.yml` y reiniciar los dos
  microservicios (`docker compose up -d --force-recreate api-pagos api-consultas`),
  sin tener que tocar la página web.
